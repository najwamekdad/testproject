

import java.util.Scanner;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author najwa
 */
public class Program {
    public static void main(String[] args){
        /**
        Scanner scan = new Scanner(System.in);
        ApartmentUI apui = new ApartmentUI(scan);
        apui.start(scan);
       */
        ProgramView programView = new ProgramView();
        programView.setVisible(true);
        
    }
    
}
