
import java.util.ArrayList;
import java.util.List;
import type.Cities;
import type.Services;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author najwa
 */
public class Apartment {
   // final static String[] CITYS = {"Stockholm", "Uppsala"};
    //final static int[] COSTS = {300, 150, 400};
    //private final static int BALCON_COST = 150;
    //private final static int TRASH_REMOVAL_COST = 400;
   // final static String[] SERVICES = {"Fönsterputs", "Balkongstädning", "Bortforsling av skräp"};
    //final static int[] METER_COSTS = {65, 55};
    //private final static int OBSAL_METER_COST = 55;
    //private int id;
    private Cities city;
    private int space;
    //private int meterCost;
    private List<Services> services;
    

    public Apartment(Cities city, int space) {
        this.city = city;
        this.space = space;
        services = new ArrayList<>();
    }

    public Cities getCity() {
        return city;
    }

    public int getSpace() {
        return space;
    }
    
    public List<Services> getServices(){
        return services;
    }
    
    public void setCity(Cities city) {
        this.city = city;
    }

    public void setSpace(int space) {
        this.space = space;
    }
    
    public void addService(Services service) {
        services.add(service);
    }
    /**
    public int printServices(){
       
        System.out.println("1: " + SERVICES.getType());
        System.out.println("2: " + SERVICES[1]);
        int i = 2;
        if (city.equals(CITYS[1])){
           System.out.println("3: " + SERVICES[1]);
           i++;
        }
        return i;
    }
    */
    public List<Services> getServicesInCity(){
        List<Services> list = new ArrayList<>();
        if(this.city.getCity().equals(Cities.STOCKHOLM.getCity())|| this.city.getCity().equals(Cities.UPPSALA.getCity())){
           list.add(Services.SERVICE1);
           list.add(Services.SERVICE2);
        }
        if (this.city.getCity().equals(Cities.UPPSALA.getCity())){
           list.add(Services.SERVICE3); 
        }
       return list; 
    }
    public int totalCost() {
        int total = 0;
        
        total += space * Cities.getCitiesbyCity(this.city.getCity()).getCost();
      
        for(Services service : services){
            
                total += service.getCost(); 
        }
        return total;
            
    }
    
}
