/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package type;

/**
 *
 * @author Najwa
 */
public enum Services {
   SERVICE1(300, "Fönsterputs"), SERVICE2(150, "Balkongstädning"),SERVICE3(400, "Bortforsling av skräp");
   
   private int cost;
   private String service;
   
    private Services(int cost, String service){
       this.cost = cost;
       this.service = service;
    }
    
    public static Services getServicesByService(String service){
        for(Services services: Services.values()){
            if(services.getService().equals(service)){
                return services;
            }
        }
        return null;
    }
    public int getCost() {
        return cost;
    }

    public String getService() {
        return service;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public void setService(String service) {
        this.service = service;
    }
   
     
}
