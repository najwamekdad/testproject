/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package type;

/**
 *
 * @author Najwa
 */
public enum Cities {
   STOCKHOLM(65, "Stockholm"), UPPSALA(55, "Uppsala");
   
   private int cost;
   private String city;
   
   private Cities(int cost, String city){
       this.cost = cost;
       this.city = city;
   }

    public int getCost() {
        return cost;
    }

    public String getCity() {
        return city;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public static Cities getCitiesbyCity(String city){
        for(Cities cities: Cities.values()){
            if (cities.getCity().equals(city)){
                return cities;
            }
        }
        return null;
    }
   
   
   
}
