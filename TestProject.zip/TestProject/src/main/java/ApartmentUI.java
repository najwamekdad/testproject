
import java.util.List;
import java.util.Scanner;
import type.Cities;
import type.Services;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author najwa
 */
public class ApartmentUI {
    
    private Scanner scan;
    public ApartmentUI(Scanner scan){
        this.scan = scan;
    }
    public void start(Scanner scan){
        while(true){
           System.out.println("Val av stad: 1 or 2");
           System.out.println("1: Stockholm");
           System.out.println("2: Uppsala");
           String s = scan.nextLine();
           if(s.equals("")){
               break;
           }    
           Cities city = null ;  
           int v = Integer.valueOf(s);
           if (v == 1){
               city = Cities.STOCKHOLM;
           } 
           if (v == 2){
               city = Cities.UPPSALA;
           }
           System.out.println(city.getCity());
           System.out.println("Hur många kvadratmeter ska städas: "); 
           s = scan.nextLine();
           Apartment apartment = new Apartment(city, Integer.valueOf(s));
           System.out.println("Vilka tillvalstjänster: Y or N"); 
           List<Services> list = apartment.getServicesInCity();
           for(int i = 0 ; i < list.size(); i++ ){
             System.out.println(i + 1 +": " + list.get(i).getService());
           }
           
           for(int i = 0 ; i < list.size(); i++ ){
               System.out.print("vill du " + list.get(i).getService() + "?");
               if(scan.nextLine().toLowerCase().equals("y")){
                   apartment.addService(list.get(i));
               }
           }
           System.out.println(apartment.getServices());
           System.out.println("Slutlig kostnad för städning krävs: " + apartment.totalCost());
        }
    }
}
